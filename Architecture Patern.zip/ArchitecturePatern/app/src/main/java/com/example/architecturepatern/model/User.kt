package com.example.architecturepatern.model

data class User(val userName : String , val yearOfBirth : Int)
