package com.example.architecturepatern.model

data class Wisdom(
    val content : String ,
    val publishDate : String)
